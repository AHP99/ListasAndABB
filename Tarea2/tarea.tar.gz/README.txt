Instrucciones de compilacion:

    1. Problema1T2.c
	1.1. El archivo que leerá el programa debe llamarse "input1.dat", tener extención .txt y además estar guardado en el mismo directorio que "Problema1T2.c".

    2. Problema2T2.c
	2.1. El archivo que leerá el programa debe llamarse "input", tener extención .txt y además estar guardado en el mismo directorio que "Problema2T2.c".
    2.2. El archivo "input" debe estar escrito en mayúsculas tal como el ejemplo entregado en el enunciado de la tarea.
    
Forma de compilación usada:

Sistema operativo: Windows 10
Terminal de Visual Studio Code con: gcc -W -Wall nombreprograma.c
Revisado con Terminal de Ubuntu en Windows (WSL), línea de comando: gcc -W -Wall nombreprograma.c

Observaciones:

Los TDA son MUY largos, se requiere mucha paciencia y amor para revisarlos, de antemano lo sentimos por eso. 